let btn = document.getElementById('btnSubmit');
let notizie = document.getElementById('notizie');
let inverval_timer;
let socket = null;
// flag che segna se l'utente si è iscritto al servizio
let isSubscribed = false;

btn.addEventListener('click', handleClick);

function handleClick() {
	
	if(!isSubscribed) {
		socket = new WebSocket('ws://localhost:8080/WS_22_12_2022/server');
		
		socket.onopen = () => {
			  console.log('WebSocket aperto');
		};
		isSubscribed = true;
		console.log("Iscrizione avvenuta con successo | status: " + isSubscribed);
		
		// Notifichiamo ad una servlet l'iscrizione di un nuovo utente
		let xhr = new XMLHttpRequest();
		xhr.open("POST", "Subscribe", true);
		xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
		xhr.send();
		
	} else
		console.log("Risulti gia iscritto al nostro servizio");
	
	inverval_timer = setInterval(function() { 
		//ricezione messaggi
	    socket.onmessage = (event) => {
	    	let message = event.data;
	    	console.log('Messaggio ricevuto: ', message);
	    	notizie.innerText += "Breaking news: "+ message;
	    };
	}, 1000);
	
	/*// Chiusura della connessione
	function closeConnection() {
	    console.log("Chiusura connessione in corso");
	    socket.close();
	}

	socket.onclose = () => {
		  console.log('WebSocket chiuso');
	};*/
}


