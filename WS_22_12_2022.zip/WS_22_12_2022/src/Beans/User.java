package Beans;

import java.util.Date;

public class User {
	private int id;
	private Date subDate;
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public Date getSubDate() {
		return subDate;
	}
	
	public void setSubDate(Date subDate) {
		this.subDate = subDate;
	}

	public User(int id, Date subDate) {
		super();
		this.id = id;
		this.subDate = subDate;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", subDate=" + subDate + "]";
	}
	
}
