package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Beans.User;

public class Admin extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) {
		//doGet method
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		if(request.getParameter("username").equals("admin") && request.getParameter("password").equals("admin")) {
			List<User> listUsers = (List<User>) this.getServletContext().getAttribute("listUsers");
			
			out.println("<h1>Lista utenti registrati</h1>");
			
			for(int i = listUsers.size() - 1; i >= 0; i--) {
				out.println(listUsers.get(i).toString());
				out.println("<br/>");
			}
		} else {
			out.println("Accesso negato");
		}
		
	}
}