package servlet;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Beans.User;

public class Subscribe extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	public void init() {
		int numOfSubs = 0;
		this.getServletContext().setAttribute("numOfSubs", numOfSubs);
		
		List<User> listUsers = new ArrayList<User>();
		this.getServletContext().setAttribute("listUsers", listUsers);
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) {
		//doGet method
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) {
		//doPost method
		int numOfSubs = (int) this.getServletContext().getAttribute("numOfSubs");
		List<User> listUsers = (List<User>) this.getServletContext().getAttribute("listUsers");
		
		// per semplicit� l'id dello User sar� lo stesso del numero di iscrizione
		// Esempio: prima persona iscritta -> id = 1
		numOfSubs++;
		User newUser = new User(numOfSubs, new Date());
		
		listUsers.add(newUser);
		
		// per un check interno
		for(User user : listUsers)
			System.out.println(user.toString());
		
		
		this.getServletContext().setAttribute("numOfSubs", numOfSubs);
		this.getServletContext().setAttribute("listUsers", listUsers);
	}
}