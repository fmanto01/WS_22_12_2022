package server;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

@ServerEndpoint("/server")
public class WebSocketServer {
	private static final Map<String, Session> sessions = Collections.synchronizedMap(new HashMap<>());

    @OnOpen
    public void onOpen(Session session) {
        String id = session.getId();
        System.out.println("Sessione aperta: " + id);
        sessions.put(id, session);
        
        // CAMBIARE PATH
        checkFile("C:\\Users\\path\\to\\risultati.txt");
    }

    @OnMessage
    public void onMessage(String message, Session session) {
        System.out.println("Messaggio ricevuto dalla sessione " + session.getId() + ": " + message);
    }

    @OnClose
    public void onClose(Session session) {
        String id = session.getId();
        System.out.println("Sessione chiusa: " + id);
        sessions.remove(id);
    }

    public static void sendMessageToAll(String message) {
        for (Session session : sessions.values()) {
            try {
                session.getBasicRemote().sendText(message);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void sendMessageToClient(String id, String message) {
        Session session = sessions.get(id);
        if (session != null) {
            try {
                session.getBasicRemote().sendText(message);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("Sessione con id " + id + " non trovata");
        }
    }
    
    public static void sendPushNotificationToClient(String id, String message) {
    	Session session = sessions.get(id);
    	if(session != null)
    		session.getAsyncRemote().sendText(message);
    	else {
    		System.out.println("Sessione con id " + id + " non trovata, "
    				+ "impossibile inviare notifica push");
    	}
    }
    
    public static void sendPushNotificationToAll(String message) {
        for (Session session : sessions.values()) {
            session.getAsyncRemote().sendText(message);
        }
    }
    
    private static void checkFile(String path) {
    	while(true) {
    		try {
        		// Specifica il percorso del file da monitorare
        		Path fileToWatch = Paths.get(path);
        		// Crea un oggetto WatchService
        		WatchService watcher = FileSystems.getDefault().newWatchService();
        		// Registra l'oggetto WatchService per ricevere notifiche di modifica
        		fileToWatch.getParent().register(watcher, StandardWatchEventKinds.ENTRY_MODIFY);
        		// Memorizza la dimensione iniziale del file
        		long lastSize = new File(fileToWatch.toString()).length();
        		// Loop infinito per attendere eventi di modifica
        		while (true) {
        		WatchKey key = watcher.take();
        		for (WatchEvent<?> event : key.pollEvents()) {
        			// Controlla se l'evento � di tipo ENTRY_MODIFY e se il nome del file modificato corrisponde al file specificato
        			if (event.kind() == StandardWatchEventKinds.ENTRY_MODIFY &&
        			event.context().toString().equals(fileToWatch.getFileName().toString())) {
        				// Legge le nuove righe aggiunte al file
        				String newContent = readNewLines(fileToWatch.toString(), lastSize);
        				
        				// Stampo a console la notizia nuova
        				System.out.println("Modifiche al file " + fileToWatch.getFileName() + ":");
        				System.out.println(newContent);
        				
        				// invio al client la notizia nuova
        				sendPushNotificationToAll(newContent);
        				
        				lastSize = new File(fileToWatch.toString()).length();
        			}
        		}
        		key.reset();
        		}
        	} catch (IOException | InterruptedException e) {
        		e.printStackTrace();
        	}
    	}
    }
    
    private static String readNewLines(String fileName, long lastSize) throws IOException {
    	StringBuilder sb = new StringBuilder();
	    	try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
	    	// Salta le righe gi� lette
	    	br.skip(lastSize);
	    	String line;
	    	while ((line = br.readLine()) != null) {
	    		sb.append(line).append("\n");
	    	}
    	}
    	return sb.toString();
    }
    
}